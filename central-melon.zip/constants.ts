import { Product } from './types';

export const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Yubari King Special',
    description: 'The crown jewel of melons. Perfectly round with a distinct net pattern and exceptionally sweet orange flesh.',
    price: 150.00,
    category: 'Premium',
    imageUrl: 'https://picsum.photos/id/1080/600/600',
    rating: 4.9,
    reviewCount: 128,
    origin: 'Hokkaido, Japan',
    harvestDate: '2023-10-25',
    stock: 15,
    qualityGrade: 'A',
    sweetnessBrix: 18
  },
  {
    id: '2',
    name: 'Emerald Musk Melon',
    description: 'A classic green-fleshed musk melon with a high fragrance and melting texture.',
    price: 45.00,
    category: 'Standard',
    imageUrl: 'https://picsum.photos/id/292/600/600',
    rating: 4.7,
    reviewCount: 340,
    origin: 'Shizuoka, Japan',
    harvestDate: '2023-10-28',
    stock: 50,
    qualityGrade: 'A',
    sweetnessBrix: 15
  },
  {
    id: '3',
    name: 'Honey Kiss Organic',
    description: 'Grown without pesticides. Golden skin and incredibly sweet, crisp flesh.',
    price: 65.00,
    category: 'Organic',
    imageUrl: 'https://picsum.photos/id/493/600/600',
    rating: 4.8,
    reviewCount: 85,
    origin: 'California, USA',
    harvestDate: '2023-11-01',
    stock: 24,
    qualityGrade: 'B',
    sweetnessBrix: 14
  },
  {
    id: '4',
    name: 'Snow Leopard Melon',
    description: 'Rare variety with variegated skin and white, pear-like flesh.',
    price: 80.00,
    category: 'Premium',
    imageUrl: 'https://picsum.photos/id/824/600/600',
    rating: 4.6,
    reviewCount: 42,
    origin: 'Xinjiang, China',
    harvestDate: '2023-10-20',
    stock: 8,
    qualityGrade: 'A',
    sweetnessBrix: 17
  },
  {
    id: '5',
    name: 'Cantaloupe Saver',
    description: 'Great for smoothies and daily breakfast. Good sweetness at an affordable price.',
    price: 12.00,
    category: 'Budget',
    imageUrl: 'https://picsum.photos/id/102/600/600',
    rating: 4.2,
    reviewCount: 560,
    origin: 'Costa Rica',
    harvestDate: '2023-11-05',
    stock: 120,
    qualityGrade: 'C',
    sweetnessBrix: 11
  }
];
