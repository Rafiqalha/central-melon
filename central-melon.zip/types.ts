export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'Premium' | 'Standard' | 'Organic' | 'Budget';
  imageUrl: string;
  rating: number;
  reviewCount: number;
  origin: string;
  harvestDate: string;
  stock: number;
  qualityGrade?: 'A' | 'B' | 'C';
  sweetnessBrix?: number;
}

export interface CartItem {
  product: Product;
  qty: number;
}

export interface AIAnalysisResult {
  grade: 'A' | 'B' | 'C' | 'Rejected';
  ripenessScore: number; // 0-100
  sweetnessPrediction: number; // Brix estimate
  defects: string[];
  reasoning: string;
}
