import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { ShoppingCart, Menu, X, Sprout, ShieldCheck, User } from 'lucide-react';
import { useAppContext } from '../App';

export const Layout: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const { cart } = useAppContext();
  const location = useLocation();
  const cartItemCount = cart.reduce((acc, item) => acc + item.qty, 0);

  return (
    <div className="flex flex-col min-h-screen bg-melon-50 font-sans text-slate-800">
      {/* Sticky Header */}
      <header className="sticky top-0 z-50 w-full bg-white/80 backdrop-blur-md border-b border-melon-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-2">
              <div className="bg-melon-500 p-1.5 rounded-lg">
                <Sprout className="h-6 w-6 text-white" />
              </div>
              <span className="font-bold text-xl tracking-tight text-melon-900">Central Melon</span>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden md:flex space-x-8 items-center">
              <Link to="/" className={`text-sm font-medium hover:text-melon-600 transition-colors ${location.pathname === '/' ? 'text-melon-600' : 'text-slate-600'}`}>Home</Link>
              <Link to="/catalog" className={`text-sm font-medium hover:text-melon-600 transition-colors ${location.pathname === '/catalog' ? 'text-melon-600' : 'text-slate-600'}`}>Catalog</Link>
              <Link to="/seller" className={`text-sm font-medium hover:text-melon-600 transition-colors ${location.pathname === '/seller' ? 'text-melon-600' : 'text-slate-600'}`}>Seller Dashboard</Link>
            </nav>

            {/* Icons */}
            <div className="flex items-center space-x-4">
              <Link to="/cart" className="relative group">
                <ShoppingCart className="h-6 w-6 text-slate-600 group-hover:text-melon-600 transition-colors" />
                {cartItemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-warm-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {cartItemCount}
                  </span>
                )}
              </Link>
              <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                {isMenuOpen ? <X className="h-6 w-6 text-slate-600" /> : <Menu className="h-6 w-6 text-slate-600" />}
              </button>
              <div className="hidden md:flex items-center justify-center h-8 w-8 rounded-full bg-melon-100 text-melon-700">
                <User className="h-5 w-5" />
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-b border-melon-200">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <Link to="/" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-melon-600 hover:bg-melon-50">Home</Link>
              <Link to="/catalog" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-melon-600 hover:bg-melon-50">Catalog</Link>
              <Link to="/seller" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-melon-600 hover:bg-melon-50">Seller Dashboard</Link>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-melon-900 text-melon-100 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Sprout className="h-6 w-6 text-melon-300" />
                <span className="font-bold text-xl text-white">Central Melon</span>
              </div>
              <p className="text-melon-200 text-sm max-w-xs">
                Connecting premium farms directly to your table using advanced AI quality assurance.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-white mb-4">Links</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/catalog" className="hover:text-white transition-colors">Shop Melons</Link></li>
                <li><Link to="/seller" className="hover:text-white transition-colors">Partner with Us</Link></li>
                <li><a href="#" className="hover:text-white transition-colors">Our Technology</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-white mb-4">Quality Guarantee</h3>
              <div className="flex items-start space-x-3">
                <ShieldCheck className="h-6 w-6 text-melon-400 flex-shrink-0" />
                <p className="text-xs text-melon-200">
                  Every fruit is scanned by our proprietary ML algorithms to ensure peak ripeness and zero defects before shipping.
                </p>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-melon-800 text-center text-xs text-melon-400">
            &copy; 2024 Central Melon Inc. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};