import React from 'react';
import { Link } from 'react-router-dom';
import { Star, ShoppingBag } from 'lucide-react';
import { Product } from '../types';
import { useAppContext } from '../App';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useAppContext();

  return (
    <div className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow duration-300 border border-gray-100 flex flex-col h-full">
      <Link to={`/product/${product.id}`} className="relative aspect-square overflow-hidden group">
        <img 
          src={product.imageUrl} 
          alt={product.name} 
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
        />
        {product.qualityGrade === 'A' && (
          <span className="absolute top-3 left-3 bg-melon-500 text-white text-xs font-bold px-2 py-1 rounded shadow-sm">
            Grade A
          </span>
        )}
      </Link>
      
      <div className="p-4 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
          <p className="text-xs font-medium text-melon-600 uppercase tracking-wider">{product.category}</p>
          <div className="flex items-center text-yellow-400 text-xs">
            <Star className="h-3 w-3 fill-current" />
            <span className="ml-1 text-gray-500">{product.rating}</span>
          </div>
        </div>
        
        <Link to={`/product/${product.id}`}>
          <h3 className="text-lg font-bold text-gray-900 mb-1 hover:text-melon-600 transition-colors line-clamp-1">{product.name}</h3>
        </Link>
        
        <p className="text-sm text-gray-500 line-clamp-2 mb-4 flex-grow">{product.description}</p>
        
        <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-50">
          <span className="text-lg font-bold text-gray-900">${product.price.toFixed(2)}</span>
          <button 
            onClick={() => addToCart(product, 1)}
            className="p-2 bg-gray-100 hover:bg-melon-500 hover:text-white rounded-full transition-colors duration-200"
            aria-label="Add to cart"
          >
            <ShoppingBag className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
};