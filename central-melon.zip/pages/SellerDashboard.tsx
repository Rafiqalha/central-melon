import React, { useState, useRef } from 'react';
import { Upload, Camera, Loader2, CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';
import { analyzeMelonImage } from '../services/geminiService';
import { AIAnalysisResult } from '../types';

export const SellerDashboard: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AIAnalysisResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setSelectedImage(base64);
        setResult(null); // Reset result on new image
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedImage) return;

    setIsAnalyzing(true);
    try {
      // Extract base64 data only (remove "data:image/jpeg;base64," prefix)
      const base64Data = selectedImage.split(',')[1];
      const analysis = await analyzeMelonImage(base64Data);
      setResult(analysis);
    } catch (error) {
      alert("Analysis failed. Please check API configuration.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Seller Dashboard</h1>
        <p className="text-gray-500 mt-2">Upload harvest photos to grade quality automatically using our ML pipeline.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Upload Section */}
        <div className="bg-white p-8 rounded-2xl border-2 border-dashed border-gray-300 hover:border-melon-400 transition-colors flex flex-col items-center justify-center min-h-[400px]">
          {selectedImage ? (
            <div className="relative w-full h-full flex flex-col items-center">
              <img src={selectedImage} alt="Preview" className="max-h-[300px] rounded-lg shadow-md object-contain mb-6" />
              <div className="flex space-x-4">
                 <button 
                   onClick={() => {setSelectedImage(null); setResult(null);}}
                   className="px-4 py-2 text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200"
                 >
                   Clear
                 </button>
                 <button 
                   onClick={handleAnalyze}
                   disabled={isAnalyzing}
                   className="px-6 py-2 bg-melon-600 text-white rounded-lg hover:bg-melon-700 disabled:opacity-50 flex items-center"
                 >
                   {isAnalyzing ? <><Loader2 className="animate-spin mr-2 h-4 w-4" /> Analyzing...</> : 'Run AI Analysis'}
                 </button>
              </div>
            </div>
          ) : (
            <div className="text-center">
              <div className="mx-auto h-16 w-16 bg-melon-100 rounded-full flex items-center justify-center mb-4">
                <Camera className="h-8 w-8 text-melon-600" />
              </div>
              <h3 className="text-lg font-medium text-gray-900">Upload Melon Photo</h3>
              <p className="mt-2 text-sm text-gray-500 mb-6">PNG, JPG up to 5MB</p>
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="px-6 py-3 bg-melon-600 text-white rounded-full shadow hover:bg-melon-700 transition-colors"
              >
                Select File
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                className="hidden" 
                accept="image/*"
              />
            </div>
          )}
        </div>

        {/* Results Section */}
        <div className="bg-gray-50 p-8 rounded-2xl border border-gray-200">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Analysis Results</h2>
          
          {!result ? (
            <div className="h-full flex flex-col items-center justify-center text-gray-400 pb-12">
              <Upload className="h-12 w-12 mb-4 opacity-20" />
              <p>Results will appear here after processing.</p>
            </div>
          ) : (
            <div className="space-y-6 animate-fade-in">
              {/* Grade Card */}
              <div className={`p-6 rounded-xl border ${
                result.grade === 'A' ? 'bg-green-50 border-green-200' : 
                result.grade === 'B' ? 'bg-yellow-50 border-yellow-200' : 
                'bg-red-50 border-red-200'
              }`}>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium uppercase tracking-wide text-gray-500">Overall Grade</span>
                  {result.grade === 'A' ? <CheckCircle2 className="text-green-600 h-6 w-6" /> : 
                   result.grade === 'Rejected' ? <XCircle className="text-red-600 h-6 w-6" /> : 
                   <AlertTriangle className="text-yellow-600 h-6 w-6" />}
                </div>
                <div className="text-4xl font-extrabold text-gray-900">{result.grade}</div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                  <div className="text-xs text-gray-500 uppercase mb-1">Ripeness</div>
                  <div className="text-2xl font-bold text-melon-700">{result.ripenessScore}%</div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5 mt-2">
                    <div className="bg-melon-500 h-1.5 rounded-full" style={{ width: `${result.ripenessScore}%` }}></div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                  <div className="text-xs text-gray-500 uppercase mb-1">Est. Sweetness</div>
                  <div className="text-2xl font-bold text-warm-500">{result.sweetnessPrediction} <span className="text-sm text-gray-400 font-normal">Brix</span></div>
                </div>
              </div>

              {/* Defects / Reasoning */}
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <h3 className="font-semibold text-gray-900 mb-3">AI Reasoning</h3>
                <p className="text-gray-600 text-sm leading-relaxed mb-4">
                  {result.reasoning}
                </p>
                
                <h4 className="font-medium text-gray-800 text-xs uppercase mb-2">Detected Issues</h4>
                {result.defects && result.defects.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {result.defects.map((defect, idx) => (
                      <span key={idx} className="px-2 py-1 bg-red-100 text-red-700 text-xs rounded-md font-medium">
                        {defect}
                      </span>
                    ))}
                  </div>
                ) : (
                  <span className="text-green-600 text-sm flex items-center">
                    <CheckCircle2 className="h-4 w-4 mr-1" /> No visible defects
                  </span>
                )}
              </div>

              <button className="w-full py-3 bg-gray-900 text-white rounded-xl font-medium hover:bg-gray-800 transition-colors">
                Save to Inventory
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};