import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Star, Truck, ShieldCheck, Award } from 'lucide-react';
import { MOCK_PRODUCTS } from '../constants';
import { useAppContext } from '../App';

export const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart } = useAppContext();
  
  const product = MOCK_PRODUCTS.find(p => p.id === id);

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold text-gray-900">Product Not Found</h2>
        <button onClick={() => navigate('/catalog')} className="mt-4 text-melon-600 hover:underline">Back to Catalog</button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <button 
        onClick={() => navigate(-1)} 
        className="flex items-center text-gray-500 hover:text-melon-600 mb-8 transition-colors"
      >
        <ArrowLeft className="h-4 w-4 mr-1" />
        Back
      </button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Image Section */}
        <div className="space-y-4">
          <div className="aspect-square rounded-3xl overflow-hidden shadow-lg bg-gray-100">
            <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
          </div>
          <div className="grid grid-cols-3 gap-4">
             {/* Thumbnails (Mocked) */}
             {[1, 2, 3].map((i) => (
               <div key={i} className="aspect-square rounded-xl overflow-hidden bg-gray-100 border border-transparent hover:border-melon-500 cursor-pointer">
                  <img src={product.imageUrl} alt="thumbnail" className="w-full h-full object-cover opacity-80 hover:opacity-100" />
               </div>
             ))}
          </div>
        </div>

        {/* Info Section */}
        <div>
          <div className="flex items-center justify-between">
            <span className="px-3 py-1 bg-melon-100 text-melon-800 rounded-full text-xs font-bold uppercase tracking-wide">
              {product.category}
            </span>
            <div className="flex items-center text-yellow-400">
              <Star className="h-5 w-5 fill-current" />
              <span className="ml-1 text-gray-700 font-semibold">{product.rating}</span>
              <span className="ml-1 text-gray-400 text-sm">({product.reviewCount} reviews)</span>
            </div>
          </div>

          <h1 className="mt-4 text-4xl font-bold text-gray-900">{product.name}</h1>
          <p className="mt-2 text-xl font-medium text-melon-700">${product.price.toFixed(2)}</p>

          <div className="mt-6 border-t border-b border-gray-100 py-6 space-y-4">
            <p className="text-gray-600 leading-relaxed">{product.description}</p>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
               <div>
                 <span className="block text-gray-400">Origin</span>
                 <span className="font-medium text-gray-900">{product.origin}</span>
               </div>
               <div>
                 <span className="block text-gray-400">Harvest Date</span>
                 <span className="font-medium text-gray-900">{product.harvestDate}</span>
               </div>
            </div>
          </div>

          {/* AI Badge */}
          <div className="mt-6 bg-gradient-to-r from-melon-50 to-white border border-melon-200 p-4 rounded-xl">
            <div className="flex items-center space-x-2 mb-2">
              <Award className="h-5 w-5 text-melon-600" />
              <h3 className="font-bold text-gray-900">AI Quality Verification</h3>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white p-3 rounded-lg shadow-sm border border-gray-100">
                <span className="text-xs text-gray-500 uppercase">Quality Grade</span>
                <div className="text-lg font-bold text-melon-700">{product.qualityGrade || 'A'}</div>
              </div>
              <div className="bg-white p-3 rounded-lg shadow-sm border border-gray-100">
                <span className="text-xs text-gray-500 uppercase">Sweetness (Brix)</span>
                <div className="text-lg font-bold text-melon-700">{product.sweetnessBrix || 14}</div>
              </div>
            </div>
          </div>

          <div className="mt-8 flex flex-col sm:flex-row gap-4">
             <div className="flex items-center border border-gray-300 rounded-full">
               <button className="px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-l-full">-</button>
               <span className="px-4 py-2 font-medium text-gray-900">1</span>
               <button className="px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-r-full">+</button>
             </div>
             <button 
               onClick={() => addToCart(product, 1)}
               className="flex-1 bg-melon-600 hover:bg-melon-700 text-white font-bold py-3 px-8 rounded-full shadow-lg shadow-melon-200 transition-all transform active:scale-95"
             >
               Add to Cart
             </button>
          </div>

          <div className="mt-8 space-y-3">
             <div className="flex items-center text-sm text-gray-500">
               <Truck className="h-4 w-4 mr-2" />
               Free delivery for orders over $100
             </div>
             <div className="flex items-center text-sm text-gray-500">
               <ShieldCheck className="h-4 w-4 mr-2" />
               100% Freshness Guarantee (Refund if rotten)
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};