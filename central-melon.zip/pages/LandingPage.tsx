import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle, TrendingUp, Truck } from 'lucide-react';
import { MOCK_PRODUCTS } from '../constants';
import { ProductCard } from '../components/ProductCard';

export const LandingPage: React.FC = () => {
  const featuredProducts = MOCK_PRODUCTS.slice(0, 3);

  return (
    <div className="animate-fade-in">
      {/* Hero Section */}
      <section className="relative bg-melon-600 overflow-hidden">
        <div className="absolute inset-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1560155016-bd4879ae8f21?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80')] bg-cover bg-center mix-blend-overlay"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32 relative z-10">
          <div className="md:w-2/3 lg:w-1/2">
            <h1 className="text-4xl md:text-6xl font-extrabold text-white leading-tight mb-6 drop-shadow-md">
              Freshness Verified by <span className="text-melon-200">Intelligence</span>
            </h1>
            <p className="text-lg md:text-xl text-melon-50 mb-8 font-medium">
              The world's first marketplace where every melon is graded by AI for perfect sweetness and texture before it leaves the farm.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link 
                to="/catalog" 
                className="inline-flex justify-center items-center px-8 py-4 border border-transparent text-base font-bold rounded-full text-melon-700 bg-white hover:bg-melon-50 transition-all shadow-lg transform hover:-translate-y-1"
              >
                Shop Catalog
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link 
                to="/seller" 
                className="inline-flex justify-center items-center px-8 py-4 border-2 border-white text-base font-bold rounded-full text-white hover:bg-white/10 transition-all"
              >
                For Farmers
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900">Why Central Melon?</h2>
            <p className="mt-4 text-gray-500">We bridge the gap between technology and agriculture.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 bg-melon-50 rounded-2xl border border-melon-100">
              <div className="w-12 h-12 bg-melon-200 rounded-xl flex items-center justify-center mb-4">
                <CheckCircle className="h-6 w-6 text-melon-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">AI Quality Badge</h3>
              <p className="text-gray-600">Our Gemini-powered scanner analyzes skin texture and color to predict brix (sweetness) levels with 92% accuracy.</p>
            </div>
            <div className="p-6 bg-melon-50 rounded-2xl border border-melon-100">
              <div className="w-12 h-12 bg-melon-200 rounded-xl flex items-center justify-center mb-4">
                <Truck className="h-6 w-6 text-melon-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Farm to Table</h3>
              <p className="text-gray-600">Direct logistics from partner farms reduces transit time by 48 hours, ensuring maximum freshness.</p>
            </div>
            <div className="p-6 bg-melon-50 rounded-2xl border border-melon-100">
              <div className="w-12 h-12 bg-melon-200 rounded-xl flex items-center justify-center mb-4">
                <TrendingUp className="h-6 w-6 text-melon-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Dynamic Pricing</h3>
              <p className="text-gray-600">Prices adjust based on real-time supply and demand, ensuring fair earnings for farmers and great deals for you.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Seasonal Showcase */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900">Seasonal Favorites</h2>
              <p className="mt-2 text-gray-500">Harvested within the last 72 hours.</p>
            </div>
            <Link to="/catalog" className="text-melon-600 font-semibold hover:text-melon-700 flex items-center">
              View All <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProducts.map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};