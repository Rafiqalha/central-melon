import React from 'react';
import { Link } from 'react-router-dom';
import { Trash2, ArrowRight, ShoppingBag } from 'lucide-react';
import { useAppContext } from '../App';

export const CartPage: React.FC = () => {
  const { cart, removeFromCart, clearCart } = useAppContext();

  const subtotal = cart.reduce((sum, item) => sum + (item.product.price * item.qty), 0);
  const shipping = subtotal > 100 ? 0 : 15;
  const total = subtotal + shipping;

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center">
        <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <ShoppingBag className="h-10 w-10 text-gray-400" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Your cart is empty</h2>
        <p className="text-gray-500 mb-8">Looks like you haven't added any fresh melons yet.</p>
        <Link to="/catalog" className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-full text-white bg-melon-600 hover:bg-melon-700">
          Start Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Shopping Cart</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-6">
          {cart.map((item) => (
            <div key={item.product.id} className="flex items-center bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
              <img src={item.product.imageUrl} alt={item.product.name} className="h-24 w-24 object-cover rounded-lg bg-gray-50" />
              
              <div className="ml-6 flex-1">
                <div className="flex justify-between">
                  <h3 className="text-lg font-bold text-gray-900">{item.product.name}</h3>
                  <p className="text-lg font-bold text-gray-900">${(item.product.price * item.qty).toFixed(2)}</p>
                </div>
                <p className="text-sm text-gray-500 mt-1">{item.product.category}</p>
                
                <div className="flex justify-between items-center mt-4">
                   <div className="text-sm text-gray-600">Qty: {item.qty}</div>
                   <button 
                     onClick={() => removeFromCart(item.product.id)}
                     className="text-red-500 hover:text-red-700 p-2 hover:bg-red-50 rounded-full transition-colors"
                   >
                     <Trash2 className="h-5 w-5" />
                   </button>
                </div>
              </div>
            </div>
          ))}
          
          <button onClick={clearCart} className="text-sm text-gray-500 hover:text-gray-700 underline">
            Clear Cart
          </button>
        </div>

        {/* Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200 sticky top-24">
            <h2 className="text-lg font-bold text-gray-900 mb-6">Order Summary</h2>
            
            <div className="space-y-4 mb-6">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Shipping</span>
                <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
              </div>
              <div className="border-t border-gray-100 pt-4 flex justify-between font-bold text-lg text-gray-900">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </div>

            <button className="w-full py-4 bg-melon-600 text-white rounded-xl font-bold text-lg hover:bg-melon-700 transition-colors shadow-lg shadow-melon-200 flex items-center justify-center">
              Checkout <ArrowRight className="ml-2 h-5 w-5" />
            </button>
            
            <div className="mt-4 text-center">
              <p className="text-xs text-gray-400">Secure Checkout powered by Stripe</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};